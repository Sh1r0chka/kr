import django_filters
from django_filters import ModelChoiceFilter
from django.forms import TextInput
from .models import Tovar, Categories


class TovarFilter(django_filters.FilterSet):
    cyclename = django_filters.CharFilter(
        field_name="cyclename", lookup_expr="icontains"
    )
    category = ModelChoiceFilter(queryset=Categories.objects.all())

    class Meta:
        model = Tovar
        fields = ["cyclename", "category__catgname"]
        # widgets = {
        #     "cyclename": TextInput(attrs={'placeholder': 'Заголовок товара', 'class': 'form-input'}),
        #     "category__catgname": django_filters.ModelChoiceFilter(attrs={'placeholder': 'Категория'}),
        # }
